# AntiDefaultCommand
A pocketmine plugin for removing some default commands.
